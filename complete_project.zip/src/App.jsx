import './App.css';
import { useState } from 'react';
import Header from './components/Header/Header';
import Banner from './components/Banner/Banner';
import CategorySidebar from './components/CategorySidebar/CategorySidebar';
import FlashDeals from './components/FlashDeals/FlashDeals';
import Products from './components/Products/Products';
import Footer from './components/Footer/Footer';
import Cart from './components/Cart/Cart';

// Import context providers
import { LanguageProvider } from './contexts/LanguageContext';
import { CurrencyProvider } from './contexts/CurrencyContext';
import { AuthProvider } from './contexts/AuthContext';
import { CartProvider } from './contexts/CartContext';

function App() {
  const [isCartOpen, setIsCartOpen] = useState(false);
  console.log("App component rendering...");

  const toggleCart = () => {
    setIsCartOpen(!isCartOpen);
  };

  return (
    <LanguageProvider>
      <CurrencyProvider>
        <AuthProvider>
          <CartProvider>
            <div className="App">
              <Header onCartClick={toggleCart} />
              <Banner />
              
              <div className="main-content container">
                <div className="content-layout">
                  <aside className="sidebar-container">
                    <CategorySidebar />
                  </aside>
                  
                  <main className="main-container">
                    <FlashDeals />
                    <Products />
                  </main>
                </div>
              </div>
              
              <Footer />
              <Cart isOpen={isCartOpen} onClose={() => setIsCartOpen(false)} />
            </div>
          </CartProvider>
        </AuthProvider>
      </CurrencyProvider>
    </LanguageProvider>
  );
}

export default App;
