import React, { useState } from 'react';
import './Header.css';
import { FaUserCircle, FaShoppingCart, FaGlobe, FaMoneyBillWave, FaSearch, FaThList } from 'react-icons/fa';
import { useAuth } from '../../contexts/AuthContext';
import { useCart } from '../../contexts/CartContext';
import { useCurrency } from '../../contexts/CurrencyContext';
import { useLanguage } from '../../contexts/LanguageContext';

const Header = ({ onCartClick }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [showLanguageMenu, setShowLanguageMenu] = useState(false);
  const [showCurrencyMenu, setShowCurrencyMenu] = useState(false);
  const [showLoginForm, setShowLoginForm] = useState(false);

  const { currentUser, login, logout, register, isAuthenticated } = useAuth();
  const { cartCount } = useCart();
  const { currentCurrency, changeCurrency, currencies } = useCurrency();
  const { currentLanguage, languages, changeLanguage, t } = useLanguage();
  
  const [loginData, setLoginData] = useState({ email: '', password: '' });
  const [registerData, setRegisterData] = useState({ name: '', email: '', password: '', confirmPassword: '' });
  const [isRegistering, setIsRegistering] = useState(false);
  
  const handleSearchChange = (e) => {
    setSearchQuery(e.target.value);
  };
  
  const handleSearchSubmit = (e) => {
    e.preventDefault();
    // Implement search functionality
    console.log('Searching for:', searchQuery);
  };

  const handleLogin = (e) => {
    e.preventDefault();
    login(loginData.email, loginData.password)
      .then(() => setShowLoginForm(false))
      .catch(error => alert(error.message));
  };

  const handleRegister = (e) => {
    e.preventDefault();
    if (registerData.password !== registerData.confirmPassword) {
      alert('Passwords do not match');
      return;
    }
    register(registerData.email, registerData.password, registerData.name)
      .then(() => setShowLoginForm(false))
      .catch(error => alert(error.message));
  };

  const toggleLoginForm = () => {
    setShowLoginForm(!showLoginForm);
    setIsRegistering(false);
  };

  return (
    <header className="header">
      <div className="header-top">
        <div className="container header-top-container">
          <div className="welcome-message">{isAuthenticated ? `Welcome back, ${currentUser.name}!` : 'Welcome to AliExpress Clone'}</div>
          <nav className="top-nav">
            <ul>
              <li className="language-selector">
                <a href="#" onClick={(e) => { e.preventDefault(); setShowLanguageMenu(!showLanguageMenu); }}>
                  <FaGlobe /> {currentLanguage.toUpperCase()}
                </a>
                {showLanguageMenu && (
                  <div className="dropdown-menu">
                    {languages.map(lang => (
                      <button
                        key={lang.code}
                        onClick={() => { changeLanguage(lang.code); setShowLanguageMenu(false); }}
                        className={currentLanguage === lang.code ? 'active' : ''}
                      >
                        {lang.name}
                      </button>
                    ))}
                  </div>
                )}
              </li>
              <li className="currency-selector">
                <a href="#" onClick={(e) => { e.preventDefault(); setShowCurrencyMenu(!showCurrencyMenu); }}>
                  <FaMoneyBillWave /> {currentCurrency}
                </a>
                {showCurrencyMenu && (
                  <div className="dropdown-menu">
                    {currencies.map(curr => (
                      <button
                        key={curr.code}
                        onClick={() => { changeCurrency(curr.code); setShowCurrencyMenu(false); }}
                        className={currentCurrency === curr.code ? 'active' : ''}
                      >
                        {curr.symbol} {curr.name}
                      </button>
                    ))}
                  </div>
                )}
              </li>
              <li><a href="#">{t('wishlist')}</a></li>
              <li><a href="#">Help</a></li>
            </ul>
          </nav>
        </div>
      </div>
      
      <div className="header-main container">
        <div className="logo-container">
          <img src="/Octocat.png" alt="Logo" className="logo" />
          <h1>AliShop</h1>
        </div>
        
        <form className="search-form" onSubmit={handleSearchSubmit}>
          <div className="search-container">
            <input
              type="text"
              className="search-input"
              placeholder="Search for products..."
              value={searchQuery}
              onChange={handleSearchChange}
            />
            <button type="submit" className="search-button">Search</button>
          </div>
          <div className="search-categories">
            <select className="category-select">
              <option value="all">All Categories</option>
              <option value="electronics">Electronics</option>
              <option value="clothing">Clothing</option>
              <option value="home">Home & Garden</option>
              <option value="toys">Toys & Hobbies</option>
            </select>
          </div>
        </form>
        
        <div className="header-actions">
          <div className="action-item" onClick={toggleLoginForm}>
            <FaUserCircle className="nav-icon" />
            <span>{isAuthenticated ? currentUser.name : t('account')}</span>
            {showLoginForm && (
              <div className="auth-dropdown">
                {isAuthenticated ? (
                  <div className="auth-form">
                    <h3>Hello, {currentUser.name}</h3>
                    <button onClick={logout} className="auth-button">Log Out</button>
                  </div>
                ) : (
                  <div className="auth-form">
                    <h3>{isRegistering ? t('register') : t('signIn')}</h3>
                    
                    {isRegistering ? (
                      <form onSubmit={handleRegister}>
                        <div className="form-group">
                          <label>Name</label>
                          <input 
                            type="text" 
                            required 
                            value={registerData.name} 
                            onChange={(e) => setRegisterData({...registerData, name: e.target.value})} 
                          />
                        </div>
                        <div className="form-group">
                          <label>{t('email')}</label>
                          <input 
                            type="email" 
                            required 
                            value={registerData.email} 
                            onChange={(e) => setRegisterData({...registerData, email: e.target.value})} 
                          />
                        </div>
                        <div className="form-group">
                          <label>{t('password')}</label>
                          <input 
                            type="password" 
                            required 
                            value={registerData.password} 
                            onChange={(e) => setRegisterData({...registerData, password: e.target.value})} 
                          />
                        </div>
                        <div className="form-group">
                          <label>{t('confirmPassword')}</label>
                          <input 
                            type="password" 
                            required 
                            value={registerData.confirmPassword} 
                            onChange={(e) => setRegisterData({...registerData, confirmPassword: e.target.value})} 
                          />
                        </div>
                        <button type="submit" className="auth-button">{t('register')}</button>
                      </form>
                    ) : (
                      <form onSubmit={handleLogin}>
                        <div className="form-group">
                          <label>{t('email')}</label>
                          <input 
                            type="email" 
                            required 
                            value={loginData.email} 
                            onChange={(e) => setLoginData({...loginData, email: e.target.value})} 
                          />
                        </div>
                        <div className="form-group">
                          <label>{t('password')}</label>
                          <input 
                            type="password" 
                            required 
                            value={loginData.password} 
                            onChange={(e) => setLoginData({...loginData, password: e.target.value})} 
                          />
                        </div>
                        <div className="form-link">
                          <a href="#" onClick={(e) => { e.preventDefault(); }}>{t('forgotPassword')}</a>
                        </div>
                        <button type="submit" className="auth-button">{t('signIn')}</button>
                      </form>
                    )}
                    
                    <div className="auth-footer">
                      {isRegistering ? (
                        <p>Already have an account? <a href="#" onClick={(e) => { e.preventDefault(); setIsRegistering(false); }}>Sign In</a></p>
                      ) : (
                        <p>New user? <a href="#" onClick={(e) => { e.preventDefault(); setIsRegistering(true); }}>Register</a></p>
                      )}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
          <div className="action-item">
            <span className="icon">❤️</span>
            <span>{t('wishlist')}</span>
          </div>
          <div className="action-item cart" onClick={onCartClick}>
            <FaShoppingCart className="nav-icon" />
            <span>{t('cart')}</span>
            <span className="cart-count">{cartCount}</span>
          </div>
        </div>
      </div>
      
      <nav className="main-nav">
        <div className="container">
          <ul className="nav-categories">
            <li className="all-categories">
              <FaThList className="nav-icon" />
              <span>All Categories</span>
              <div className="dropdown-icon">▼</div>
            </li>
            <li><a href="#">Flash Deals</a></li>
            <li><a href="#">Best Seller</a></li>
            <li><a href="#">Electronics</a></li>
            <li><a href="#">Fashion</a></li>
            <li><a href="#">Home & Garden</a></li>
            <li><a href="#">Beauty</a></li>
            <li><a href="#">Toys</a></li>
          </ul>
        </div>
      </nav>
    </header>
  );
};

export default Header;